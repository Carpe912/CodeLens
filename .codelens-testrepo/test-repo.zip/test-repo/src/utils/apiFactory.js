const axios = require('axios');

/**
 * API路径工厂
 * 使用工厂模式动态生成API路径
 */
class ApiPathFactory {
  constructor(baseURL, apiVersion = 'v1') {
    this.baseURL = baseURL;
    this.apiVersion = apiVersion;
    this.pathCache = new Map();
  }

  /**
   * 生成资源路径
   */
  resource(name) {
    return `/api/${this.apiVersion}/${name}`;
  }

  /**
   * 生成带ID的资源路径
   */
  resourceWithId(name, id) {
    return `${this.resource(name)}/${id}`;
  }

  /**
   * 生成嵌套资源路径
   */
  nestedResource(parentName, parentId, childName, childId = null) {
    const base = `${this.resource(parentName)}/${parentId}/${childName}`;
    return childId ? `${base}/${childId}` : base;
  }

  /**
   * 使用模板生成路径
   */
  fromTemplate(template, params) {
    let path = template;
    for (const [key, value] of Object.entries(params)) {
      path = path.replace(`:${key}`, value);
    }
    return path;
  }

  /**
   * 缓存路径生成结果
   */
  getCachedPath(key, generator) {
    if (this.pathCache.has(key)) {
      return this.pathCache.get(key);
    }
    const path = generator();
    this.pathCache.set(key, path);
    return path;
  }
}

/**
 * 高级API客户端
 * 使用工厂模式和各种复杂路径构建技术
 */
class AdvancedApiClient {
  constructor(baseURL) {
    this.baseURL = baseURL;
    this.factory = new ApiPathFactory(baseURL);
    this.client = axios.create({ baseURL });
  }

  /**
   * 使用工厂方法生成路径
   */
  async getResource(resourceName, id = null) {
    const path = id
      ? this.factory.resourceWithId(resourceName, id)
      : this.factory.resource(resourceName);
    return this.client.get(path);
  }

  /**
   * 使用嵌套资源路径
   */
  async getNestedResource(parent, parentId, child, childId = null) {
    const path = this.factory.nestedResource(parent, parentId, child, childId);
    return this.client.get(path);
  }

  /**
   * 使用模板路径
   */
  async getUserOrderItem(userId, orderId, itemId) {
    const template = '/api/v1/users/:userId/orders/:orderId/items/:itemId';
    const path = this.factory.fromTemplate(template, { userId, orderId, itemId });
    return this.client.get(path);
  }

  /**
   * 使用缓存的路径
   */
  async getCachedResource(resourceName, id) {
    const cacheKey = `${resourceName}-${id}`;
    const path = this.factory.getCachedPath(
      cacheKey,
      () => this.factory.resourceWithId(resourceName, id)
    );
    return this.client.get(path);
  }

  /**
   * 使用数组映射生成批量请求
   */
  async batchGetResources(resourceName, ids) {
    const requests = ids.map(id => {
      const path = this.factory.resourceWithId(resourceName, id);
      return this.client.get(path);
    });
    return Promise.all(requests);
  }

  /**
   * 使用对象解构和展开运算符
   */
  async searchWithFilters(resourceName, { query, filters = {}, pagination = {} }) {
    const basePath = this.factory.resource(resourceName);
    const searchPath = `${basePath}/search`;

    const params = {
      q: query,
      ...filters,
      ...pagination
    };

    return this.client.get(searchPath, { params });
  }

  /**
   * 使用条件链式调用
   */
  async getResourceWithRelations(resourceName, id, relations = []) {
    let path = this.factory.resourceWithId(resourceName, id);

    if (relations.length > 0) {
      const include = relations.join(',');
      path += `?include=${include}`;
    }

    return this.client.get(path);
  }

  /**
   * 使用动态方法名
   */
  createResourceMethod(resourceName, method) {
    return (id, data) => {
      const path = this.factory.resourceWithId(resourceName, id);
      return this.client[method](path, data);
    };
  }

  /**
   * 使用Proxy动态生成方法
   */
  createDynamicApi(resourceName) {
    const factory = this.factory;
    const client = this.client;

    return new Proxy({}, {
      get(target, prop) {
        if (prop === 'list') {
          return () => client.get(factory.resource(resourceName));
        }
        if (prop === 'get') {
          return (id) => client.get(factory.resourceWithId(resourceName, id));
        }
        if (prop === 'create') {
          return (data) => client.post(factory.resource(resourceName), data);
        }
        if (prop === 'update') {
          return (id, data) => client.put(factory.resourceWithId(resourceName, id), data);
        }
        if (prop === 'delete') {
          return (id) => client.delete(factory.resourceWithId(resourceName, id));
        }
        // 自定义子资源访问
        return (id) => {
          const subPath = `${factory.resourceWithId(resourceName, id)}/${prop}`;
          return client.get(subPath);
        };
      }
    });
  }

  /**
   * 使用生成器函数构建路径序列
   */
  *generatePaths(resourceName, ids) {
    for (const id of ids) {
      yield this.factory.resourceWithId(resourceName, id);
    }
  }

  async batchGetWithGenerator(resourceName, ids) {
    const paths = [...this.generatePaths(resourceName, ids)];
    const requests = paths.map(path => this.client.get(path));
    return Promise.all(requests);
  }

  /**
   * 使用async迭代器
   */
  async *fetchPaginated(resourceName, totalPages) {
    for (let page = 1; page <= totalPages; page++) {
      const path = `${this.factory.resource(resourceName)}?page=${page}`;
      const response = await this.client.get(path);
      yield response.data;
    }
  }

  /**
   * 使用WeakMap存储私有路径配置
   */
  static pathConfigs = new WeakMap();

  setPathConfig(config) {
    AdvancedApiClient.pathConfigs.set(this, config);
  }

  getConfiguredPath(key) {
    const config = AdvancedApiClient.pathConfigs.get(this);
    return config?.[key] || null;
  }
}

module.exports = { ApiPathFactory, AdvancedApiClient };
