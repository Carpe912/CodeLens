const express = require('express');
const router = express.Router();

/**
 * Product routes
 */

// GET /api/products - List products with pagination
router.get('/api/products', async (req, res) => {
  const { page = 1, limit = 20 } = req.query;
  res.json({ products: [], page, limit });
});

// GET /api/products/:id - Get product details
router.get('/api/products/:id', async (req, res) => {
  const { id } = req.params;
  res.json({ id, name: 'Product Name', price: 99.99 });
});

// GET /api/products/category/:category - Get products by category
router.get('/api/products/category/:category', async (req, res) => {
  const { category } = req.params;
  res.json({ category, products: [] });
});

// POST /api/products - Create product
router.post('/api/products', async (req, res) => {
  const productData = req.body;
  res.status(201).json({ id: 1, ...productData });
});

// PUT /api/products/:id - Update product
router.put('/api/products/:id', async (req, res) => {
  const { id } = req.params;
  const productData = req.body;
  res.json({ id, ...productData });
});

// DELETE /api/products/:id - Delete product
router.delete('/api/products/:id', async (req, res) => {
  const { id } = req.params;
  res.status(204).send();
});

// GET /api/products/search - Search products
router.get('/api/products/search', async (req, res) => {
  const { q } = req.query;
  res.json({ query: q, results: [] });
});

module.exports = router;
