const express = require('express');
const { API_PREFIX, RESOURCES } = require('../config/apiConfig');

const router = express.Router();

/**
 * 复杂路由定义
 * 使用常量、变量和动态路径
 */

// 使用常量定义基础路由
const BASE = API_PREFIX;
const USER_BASE = `${BASE}/${RESOURCES.USERS}`;
const ORDER_BASE = `${BASE}/${RESOURCES.ORDERS}`;

// 简单资源路由
router.get(`${USER_BASE}`, (req, res) => {
  res.json({ users: [] });
});

// 带参数的路由
router.get(`${USER_BASE}/:id`, (req, res) => {
  res.json({ id: req.params.id });
});

// 嵌套资源路由
router.get(`${USER_BASE}/:userId/orders`, (req, res) => {
  res.json({ userId: req.params.userId, orders: [] });
});

// 多层嵌套路由
router.get(`${USER_BASE}/:userId/orders/:orderId/items`, (req, res) => {
  res.json({ userId: req.params.userId, orderId: req.params.orderId, items: [] });
});

// 三层嵌套路由
router.get(`${USER_BASE}/:userId/orders/:orderId/items/:itemId`, (req, res) => {
  res.json({ userId: req.params.userId, orderId: req.params.orderId, itemId: req.params.itemId });
});

// 使用数组定义多个HTTP方法
['get', 'post', 'put', 'delete'].forEach(method => {
  router[method](`${ORDER_BASE}/:id`, (req, res) => {
    res.json({ method: method.toUpperCase(), orderId: req.params.id });
  });
});

// 使用循环定义多个相似路由
const userSubResources = ['profile', 'settings', 'notifications', 'preferences'];
userSubResources.forEach(resource => {
  router.get(`${USER_BASE}/:userId/${resource}`, (req, res) => {
    res.json({ userId: req.params.userId, resource });
  });
});

// 使用对象定义路由配置
const routeConfigs = [
  { path: 'addresses', methods: ['get', 'post'] },
  { path: 'payment-methods', methods: ['get', 'post', 'delete'] },
  { path: 'wishlist', methods: ['get', 'post'] }
];

routeConfigs.forEach(config => {
  config.methods.forEach(method => {
    const fullPath = `${USER_BASE}/:userId/${config.path}`;
    router[method](fullPath, (req, res) => {
      res.json({ userId: req.params.userId, resource: config.path, method });
    });
  });
});

// 使用函数生成路由
function createResourceRoutes(basePath, resourceName) {
  router.get(`${basePath}/${resourceName}`, (req, res) => {
    res.json({ resource: resourceName, action: 'list' });
  });

  router.get(`${basePath}/${resourceName}/:id`, (req, res) => {
    res.json({ resource: resourceName, action: 'get', id: req.params.id });
  });

  router.post(`${basePath}/${resourceName}`, (req, res) => {
    res.json({ resource: resourceName, action: 'create' });
  });

  router.put(`${basePath}/${resourceName}/:id`, (req, res) => {
    res.json({ resource: resourceName, action: 'update', id: req.params.id });
  });

  router.delete(`${basePath}/${resourceName}/:id`, (req, res) => {
    res.json({ resource: resourceName, action: 'delete', id: req.params.id });
  });
}

// 使用函数批量创建路由
createResourceRoutes(BASE, 'categories');
createResourceRoutes(BASE, 'tags');
createResourceRoutes(BASE, 'reviews');

// 使用正则表达式路由
router.get(`${BASE}/products/:id(\\d+)`, (req, res) => {
  res.json({ productId: req.params.id, type: 'numeric' });
});

router.get(`${BASE}/products/:slug([a-z-]+)`, (req, res) => {
  res.json({ productSlug: req.params.slug, type: 'slug' });
});

// 使用可选参数
router.get(`${BASE}/search/:type?`, (req, res) => {
  res.json({ searchType: req.params.type || 'all' });
});

// 使用通配符路由
router.get(`${BASE}/files/*`, (req, res) => {
  res.json({ filePath: req.params[0] });
});

// 使用路由参数和查询参数组合
router.get(`${BASE}/products/:categoryId/items`, (req, res) => {
  const { page, limit, sort } = req.query;
  res.json({ categoryId: req.params.categoryId, page, limit, sort });
});

// 使用中间件链
const authenticate = (req, res, next) => next();
const authorize = (req, res, next) => next();

router.get(`${BASE}/admin/users/:id`, authenticate, authorize, (req, res) => {
  res.json({ adminUserId: req.params.id });
});

// 使用路由组
const adminRouter = express.Router();
adminRouter.get('/dashboard', (req, res) => res.json({ page: 'dashboard' }));
adminRouter.get('/users', (req, res) => res.json({ page: 'users' }));
adminRouter.get('/settings', (req, res) => res.json({ page: 'settings' }));
router.use(`${BASE}/admin`, adminRouter);

// 使用动态路由前缀
const API_VERSIONS = ['v1', 'v2', 'v3'];
API_VERSIONS.forEach(version => {
  router.get(`/api/${version}/status`, (req, res) => {
    res.json({ version, status: 'ok' });
  });
});

// 使用条件路由
const FEATURE_FLAGS = {
  enableBeta: true,
  enableExperimental: false
};

if (FEATURE_FLAGS.enableBeta) {
  router.get(`${BASE}/beta/features`, (req, res) => {
    res.json({ features: ['feature1', 'feature2'] });
  });
}

if (FEATURE_FLAGS.enableExperimental) {
  router.get(`${BASE}/experimental/features`, (req, res) => {
    res.json({ features: ['exp1', 'exp2'] });
  });
}

// 使用路由工厂函数
function createNestedRoutes(parent, parentParam, child, childParam) {
  const basePath = `${BASE}/${parent}/:${parentParam}/${child}`;

  router.get(basePath, (req, res) => {
    res.json({ [parentParam]: req.params[parentParam], action: 'list' });
  });

  router.get(`${basePath}/:${childParam}`, (req, res) => {
    res.json({
      [parentParam]: req.params[parentParam],
      [childParam]: req.params[childParam]
    });
  });
}

createNestedRoutes('users', 'userId', 'posts', 'postId');
createNestedRoutes('users', 'userId', 'comments', 'commentId');
createNestedRoutes('products', 'productId', 'reviews', 'reviewId');

module.exports = router;
