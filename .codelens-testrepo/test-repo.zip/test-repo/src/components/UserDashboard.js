const { ApiPaths, API_PREFIX, RESOURCES } = require('../config/apiConfig');
const AdvancedUserApi = require('../api/advancedUserApi');
const ComplexProductApi = require('../api/complexProductApi');
const DynamicOrderApi = require('../api/dynamicOrderApi');

/**
 * 业务组件：用户仪表板
 * 模拟真实业务场景中的API调用
 */
class UserDashboard {
  constructor(baseURL, userId) {
    this.baseURL = baseURL;
    this.userId = userId;
    this.userApi = new AdvancedUserApi(baseURL);
    this.productApi = new ComplexProductApi(baseURL);
    this.orderApi = new DynamicOrderApi(baseURL, userId);
  }

  /**
   * 加载用户仪表板数据
   * 组合多个API调用
   */
  async loadDashboard() {
    // 并行请求多个接口
    const [userProfile, recentOrders, recommendations] = await Promise.all([
      this.userApi.getUserProfile(this.userId),
      this.orderApi.getMyOrders(),
      this.getRecommendations()
    ]);

    return {
      profile: userProfile.data,
      orders: recentOrders.data,
      recommendations: recommendations.data
    };
  }

  /**
   * 获取推荐产品
   * 根据用户历史订单推荐
   */
  async getRecommendations() {
    // 先获取用户订单历史
    const orders = await this.orderApi.getOrderHistory({ limit: 10 });

    // 提取产品ID
    const productIds = orders.data.flatMap(order =>
      order.items.map(item => item.productId)
    );

    // 为每个产品获取推荐
    const recommendationRequests = productIds.slice(0, 3).map(productId =>
      this.productApi.getProductRelatedData(productId, 'recommended')
    );

    return Promise.all(recommendationRequests);
  }

  /**
   * 处理订单详情页
   * 传入订单ID，加载完整订单信息
   */
  async loadOrderDetails(orderId) {
    // 获取订单基本信息
    const order = await this.orderApi.getOrderDetail(orderId);

    // 获取订单中每个商品的详细信息
    const itemDetails = await Promise.all(
      order.data.items.map(item =>
        this.orderApi.getOrderItem(orderId, item.id)
      )
    );

    // 获取物流信息
    const tracking = await this.orderApi.getOrderTracking(orderId);

    return {
      order: order.data,
      items: itemDetails.map(res => res.data),
      tracking: tracking.data
    };
  }

  /**
   * 处理产品详情页
   * 传入产品ID，加载产品相关所有数据
   */
  async loadProductDetails(productId) {
    const [product, reviews, similar, specifications] = await Promise.all([
      this.productApi.getProductById(productId),
      this.productApi.getProductReviews(productId),
      this.productApi.getProductRelatedData(productId, 'similar'),
      this.productApi.getProductData(productId, 'specifications')
    ]);

    return {
      product: product.data,
      reviews: reviews.data,
      similar: similar.data,
      specifications: specifications.data
    };
  }

  /**
   * 搜索产品并按分类过滤
   * 业务逻辑决定API调用路径
   */
  async searchAndFilter(query, filters = {}) {
    const { category, priceRange, sortBy } = filters;

    // 如果指定了分类，使用分类专用接口
    if (category) {
      const categoryProducts = await this.productApi.getProductsByCategory(category);
      return this.applyFilters(categoryProducts.data, { priceRange, sortBy });
    }

    // 否则使用搜索接口
    const searchResults = await this.productApi.searchProducts({
      query,
      minPrice: priceRange?.min,
      maxPrice: priceRange?.max
    });

    return searchResults.data;
  }

  /**
   * 批量操作订单
   * 根据业务条件决定调用哪些API
   */
  async batchProcessOrders(orderIds, action) {
    const results = [];

    for (const orderId of orderIds) {
      try {
        let result;
        switch (action) {
          case 'cancel':
            result = await this.orderApi.cancelOrder(orderId, 'User requested');
            break;
          case 'track':
            result = await this.orderApi.getOrderTracking(orderId);
            break;
          case 'invoice':
            const pathBuilder = this.orderApi.buildOrderPath(orderId);
            result = await this.orderApi.client.get(pathBuilder.invoice());
            break;
          default:
            result = await this.orderApi.getOrderDetail(orderId);
        }
        results.push({ orderId, success: true, data: result.data });
      } catch (error) {
        results.push({ orderId, success: false, error: error.message });
      }
    }

    return results;
  }

  /**
   * 用户内容管理
   * 根据内容类型动态构建请求
   */
  async manageUserContent(contentType, action, contentId = null) {
    const basePath = `${API_PREFIX}/${RESOURCES.USERS}/${this.userId}`;

    let endpoint;
    switch (contentType) {
      case 'reviews':
        endpoint = contentId
          ? `${basePath}/reviews/${contentId}`
          : `${basePath}/reviews`;
        break;
      case 'wishlist':
        endpoint = contentId
          ? `${basePath}/wishlist/${contentId}`
          : `${basePath}/wishlist`;
        break;
      case 'cart':
        endpoint = contentId
          ? `${basePath}/cart/items/${contentId}`
          : `${basePath}/cart`;
        break;
      default:
        endpoint = `${basePath}/${contentType}`;
    }

    // 根据action决定HTTP方法
    switch (action) {
      case 'get':
        return this.userApi.client.get(endpoint);
      case 'create':
        return this.userApi.client.post(endpoint);
      case 'update':
        return this.userApi.client.put(endpoint);
      case 'delete':
        return this.userApi.client.delete(endpoint);
      default:
        return this.userApi.client.get(endpoint);
    }
  }

  /**
   * 辅助方法：应用过滤器
   */
  applyFilters(products, filters) {
    let filtered = [...products];

    if (filters.priceRange) {
      filtered = filtered.filter(p =>
        p.price >= filters.priceRange.min &&
        p.price <= filters.priceRange.max
      );
    }

    if (filters.sortBy === 'price_asc') {
      filtered.sort((a, b) => a.price - b.price);
    } else if (filters.sortBy === 'price_desc') {
      filtered.sort((a, b) => b.price - a.price);
    }

    return filtered;
  }
}

module.exports = UserDashboard;
