const axios = require('axios');

/**
 * Product API client
 */
class ProductApi {
  constructor(baseURL) {
    this.baseURL = baseURL;
  }

  // GET /api/products - List products with pagination
  async getProducts(page = 1, limit = 20) {
    const response = await fetch(`${this.baseURL}/api/products?page=${page}&limit=${limit}`);
    return response.json();
  }

  // GET /api/products/:id - Get product details
  async getProductById(id) {
    const response = await fetch(`${this.baseURL}/api/products/${id}`);
    return response.json();
  }

  // GET /api/products/category/:category - Get products by category
  async getProductsByCategory(category) {
    return axios.get(`${this.baseURL}/api/products/category/${category}`);
  }

  // POST /api/products - Create product
  async createProduct(productData) {
    return fetch(`${this.baseURL}/api/products`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(productData)
    });
  }

  // GET /api/products/search - Search products
  async searchProducts(query) {
    return axios.get(`${this.baseURL}/api/products/search`, {
      params: { q: query }
    });
  }
}

module.exports = ProductApi;
