const axios = require('axios');
const { ApiPaths, API_PREFIX, RESOURCES } = require('../config/apiConfig');

/**
 * 高级用户API客户端
 * 使用配置文件中的路径常量和动态路径构建
 */
class AdvancedUserApi {
  constructor(baseURL) {
    this.client = axios.create({ baseURL });
  }

  // 使用ApiPaths对象获取用户列表
  async getUsers() {
    const path = ApiPaths.users.list();
    return this.client.get(path);
  }

  // 使用动态路径构建获取用户详情
  async getUserById(id) {
    const path = ApiPaths.users.detail(id);
    return this.client.get(path);
  }

  // 使用模板字符串和常量组合
  async getUserProfile(userId) {
    const endpoint = `${API_PREFIX}/${RESOURCES.USERS}/${userId}/profile`;
    return this.client.get(endpoint);
  }

  // 使用函数返回值作为路径
  async updateUserAvatar(userId, avatarData) {
    return this.client.put(ApiPaths.users.avatar(userId), avatarData);
  }

  // 复杂的路径拼接：常量 + 变量 + 子资源
  async getUserSettings(userId) {
    const basePath = `${API_PREFIX}/${RESOURCES.USERS}`;
    const fullPath = `${basePath}/${userId}/settings`;
    return this.client.get(fullPath);
  }

  // 条件路径构建
  async getUserData(userId, includeOrders = false) {
    const basePath = ApiPaths.users.detail(userId);
    const path = includeOrders ? `${basePath}/orders` : basePath;
    return this.client.get(path);
  }

  // 使用对象解构和路径拼接
  async getUserNotifications(userId, { page = 1, unreadOnly = false } = {}) {
    const endpoint = `${API_PREFIX}/${RESOURCES.USERS}/${userId}/notifications`;
    const params = { page, unread: unreadOnly };
    return this.client.get(endpoint, { params });
  }

  // 多层嵌套路径
  async getUserOrderItem(userId, orderId, itemId) {
    const path = `${API_PREFIX}/${RESOURCES.USERS}/${userId}/${RESOURCES.ORDERS}/${orderId}/items/${itemId}`;
    return this.client.get(path);
  }

  // 使用数组join构建路径
  async getUserAddress(userId, addressId) {
    const pathSegments = [API_PREFIX, RESOURCES.USERS, userId, 'addresses', addressId];
    const path = pathSegments.join('/');
    return this.client.get(path);
  }

  // 使用三元运算符决定路径
  async getUserContent(userId, contentType) {
    const resource = contentType === 'posts' ? 'posts' : 'comments';
    const path = `${API_PREFIX}/${RESOURCES.USERS}/${userId}/${resource}`;
    return this.client.get(path);
  }
}

module.exports = AdvancedUserApi;
