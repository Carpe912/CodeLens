const axios = require('axios');

/**
 * User API client
 */
class UserApi {
  constructor(baseURL) {
    this.client = axios.create({ baseURL });
  }

  // GET /api/users - List all users
  async getUsers() {
    return this.client.get('/api/users');
  }

  // GET /api/users/:id - Get user by ID
  async getUserById(id) {
    return this.client.get(`/api/users/${id}`);
  }

  // POST /api/users - Create new user
  async createUser(userData) {
    return this.client.post('/api/users', userData);
  }

  // PUT /api/users/:id - Update user
  async updateUser(id, userData) {
    return this.client.put(`/api/users/${id}`, userData);
  }

  // DELETE /api/users/:id - Delete user
  async deleteUser(id) {
    return this.client.delete(`/api/users/${id}`);
  }

  // GET /api/users/:id/profile - Get user profile
  async getUserProfile(id) {
    return axios.get(`/api/users/${id}/profile`);
  }
}

module.exports = UserApi;
