const axios = require('axios');

/**
 * Order API client
 */
class OrderApi {
  constructor(baseURL) {
    this.client = axios.create({ baseURL });
  }

  // GET /api/orders - List all orders
  async getOrders() {
    return this.client.get('/api/orders');
  }

  // GET /api/orders/:id - Get order by ID
  async getOrderById(id) {
    return this.client.get(`/api/orders/${id}`);
  }

  // POST /api/orders - Create new order
  async createOrder(orderData) {
    return this.client.post('/api/orders', orderData);
  }

  // PATCH /api/orders/:id/status - Update order status
  async updateOrderStatus(id, status) {
    return axios.patch(`/api/orders/${id}/status`, { status });
  }

  // GET /api/orders/:orderId/items - Get order items
  async getOrderItems(orderId) {
    const response = await fetch(`${this.client.defaults.baseURL}/api/orders/${orderId}/items`);
    return response.json();
  }

  // GET /api/orders/:orderId/items/:itemId - Get specific order item
  async getOrderItem(orderId, itemId) {
    return this.client.get(`/api/orders/${orderId}/items/${itemId}`);
  }

  // PUT /api/orders/:orderId/items/:itemId - Update order item
  async updateOrderItem(orderId, itemId, itemData) {
    return fetch(`${this.client.defaults.baseURL}/api/orders/${orderId}/items/${itemId}`, {
      method: 'PUT',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(itemData)
    });
  }
}

module.exports = OrderApi;
