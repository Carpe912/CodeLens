const axios = require('axios');
const { ApiPaths, API_PREFIX, RESOURCES } = require('../config/apiConfig');

/**
 * 动态订单API客户端
 * 测试业务组件中传入参数的场景
 */
class DynamicOrderApi {
  constructor(baseURL, userId) {
    this.baseURL = baseURL;
    this.userId = userId;
    this.client = axios.create({ baseURL });
  }

  // 使用实例属性构建路径
  async getMyOrders() {
    const path = `${API_PREFIX}/${RESOURCES.USERS}/${this.userId}/${RESOURCES.ORDERS}`;
    return this.client.get(path);
  }

  // 使用传入参数和实例属性组合
  async getOrderDetail(orderId) {
    const path = ApiPaths.orders.detail(orderId);
    return this.client.get(path);
  }

  // 使用多个参数构建复杂路径
  async getOrderItem(orderId, itemId) {
    const path = `${API_PREFIX}/${RESOURCES.ORDERS}/${orderId}/items/${itemId}`;
    return this.client.get(path);
  }

  // 使用可选参数和条件路径
  async getOrderHistory(options = {}) {
    const { status, startDate, endDate, page = 1, limit = 20 } = options;
    let path = `${API_PREFIX}/${RESOURCES.USERS}/${this.userId}/${RESOURCES.ORDERS}`;

    const params = [];
    if (status) params.push(`status=${status}`);
    if (startDate) params.push(`start_date=${startDate}`);
    if (endDate) params.push(`end_date=${endDate}`);
    params.push(`page=${page}`);
    params.push(`limit=${limit}`);

    if (params.length > 0) {
      path += `?${params.join('&')}`;
    }

    return this.client.get(path);
  }

  // 使用循环构建批量请求路径
  async getMultipleOrders(orderIds) {
    const requests = orderIds.map(orderId => {
      const path = `${API_PREFIX}/${RESOURCES.ORDERS}/${orderId}`;
      return this.client.get(path);
    });
    return Promise.all(requests);
  }

  // 使用对象方法链式调用
  buildOrderPath(orderId) {
    const base = `${API_PREFIX}/${RESOURCES.ORDERS}/${orderId}`;
    return {
      items: () => `${base}/items`,
      tracking: () => `${base}/tracking`,
      invoice: () => `${base}/invoice`,
      refund: () => `${base}/refund`,
      itemDetail: (itemId) => `${base}/items/${itemId}`
    };
  }

  async getOrderTracking(orderId) {
    const pathBuilder = this.buildOrderPath(orderId);
    return this.client.get(pathBuilder.tracking());
  }

  // 使用异步方法获取路径参数
  async getOrderItemsByStatus(orderId, status) {
    const itemsPath = `${API_PREFIX}/${RESOURCES.ORDERS}/${orderId}/items`;
    const response = await this.client.get(itemsPath);

    // 根据状态过滤后再请求详情
    const filteredItems = response.data.filter(item => item.status === status);
    const detailRequests = filteredItems.map(item => {
      const detailPath = `${API_PREFIX}/${RESOURCES.ORDERS}/${orderId}/items/${item.id}`;
      return this.client.get(detailPath);
    });

    return Promise.all(detailRequests);
  }

  // 使用try-catch和备用路径
  async getOrderWithFallback(orderId) {
    try {
      const primaryPath = `${API_PREFIX}/${RESOURCES.ORDERS}/${orderId}`;
      return await this.client.get(primaryPath);
    } catch (error) {
      // 如果主路径失败，尝试备用路径
      const fallbackPath = `${API_PREFIX}/${RESOURCES.USERS}/${this.userId}/${RESOURCES.ORDERS}/${orderId}`;
      return await this.client.get(fallbackPath);
    }
  }

  // 使用递归构建嵌套路径
  buildNestedPath(segments, index = 0) {
    if (index >= segments.length) {
      return API_PREFIX;
    }
    const current = segments[index];
    const rest = this.buildNestedPath(segments, index + 1);
    return index === 0 ? `${rest}/${current}` : `${current}/${rest}`;
  }

  async getNestedOrderData(orderId, itemId, attributeId) {
    const segments = [RESOURCES.ORDERS, orderId, 'items', itemId, 'attributes', attributeId];
    const path = `${API_PREFIX}/${segments.join('/')}`;
    return this.client.get(path);
  }

  // 使用高阶函数生成请求方法
  createOrderRequest(action) {
    return (orderId, data) => {
      const path = `${API_PREFIX}/${RESOURCES.ORDERS}/${orderId}/${action}`;
      return this.client.post(path, data);
    };
  }

  async cancelOrder(orderId, reason) {
    const cancelRequest = this.createOrderRequest('cancel');
    return cancelRequest(orderId, { reason });
  }

  async returnOrder(orderId, items) {
    const returnRequest = this.createOrderRequest('return');
    return returnRequest(orderId, { items });
  }
}

module.exports = DynamicOrderApi;
