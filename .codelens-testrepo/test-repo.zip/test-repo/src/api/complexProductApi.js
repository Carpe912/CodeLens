const axios = require('axios');
const { API_PREFIX, API_V2_PREFIX, RESOURCES, buildApiPath } = require('../config/apiConfig');

/**
 * 复杂产品API客户端
 * 测试各种复杂的路径构建场景
 */
class ComplexProductApi {
  constructor(baseURL) {
    this.baseURL = baseURL;
    this.apiVersion = 'v1';
  }

  // 使用类属性构建路径
  getApiPath(resource) {
    return `${this.baseURL}/api/${this.apiVersion}/${resource}`;
  }

  // 使用方法返回值作为路径
  async getProducts() {
    const endpoint = this.getApiPath(RESOURCES.PRODUCTS);
    return axios.get(endpoint);
  }

  // 使用工具函数构建路径
  async getProductById(id) {
    const basePath = buildApiPath(RESOURCES.PRODUCTS);
    return axios.get(`${this.baseURL}${basePath}/${id}`);
  }

  // 使用对象属性和计算属性
  async getProductsByCategory(categoryId) {
    const paths = {
      products: `${API_PREFIX}/${RESOURCES.PRODUCTS}`,
      categories: `${API_PREFIX}/${RESOURCES.CATEGORIES}`
    };
    const endpoint = `${paths.categories}/${categoryId}/products`;
    return axios.get(`${this.baseURL}${endpoint}`);
  }

  // 使用switch语句决定路径
  async getProductData(productId, dataType) {
    let subPath;
    switch (dataType) {
      case 'reviews':
        subPath = 'reviews';
        break;
      case 'specifications':
        subPath = 'specs';
        break;
      case 'images':
        subPath = 'gallery';
        break;
      default:
        subPath = 'details';
    }
    const path = `${API_PREFIX}/${RESOURCES.PRODUCTS}/${productId}/${subPath}`;
    return axios.get(`${this.baseURL}${path}`);
  }

  // 使用Map存储路径模板
  async getProductRelatedData(productId, relationType) {
    const relationPaths = new Map([
      ['similar', `${API_PREFIX}/${RESOURCES.PRODUCTS}/${productId}/similar`],
      ['recommended', `${API_PREFIX}/${RESOURCES.PRODUCTS}/${productId}/recommendations`],
      ['alternatives', `${API_PREFIX}/${RESOURCES.PRODUCTS}/${productId}/alternatives`]
    ]);
    const path = relationPaths.get(relationType);
    return axios.get(`${this.baseURL}${path}`);
  }

  // 使用闭包构建路径
  createProductEndpoint(productId) {
    const base = `${API_PREFIX}/${RESOURCES.PRODUCTS}/${productId}`;
    return {
      reviews: () => `${base}/reviews`,
      ratings: () => `${base}/ratings`,
      questions: () => `${base}/questions`
    };
  }

  async getProductReviews(productId) {
    const endpoints = this.createProductEndpoint(productId);
    return axios.get(`${this.baseURL}${endpoints.reviews()}`);
  }

  // 使用数组reduce构建路径
  async getNestedProductData(categoryId, subcategoryId, productId) {
    const segments = ['categories', categoryId, 'subcategories', subcategoryId, 'products', productId];
    const path = segments.reduce((acc, segment) => `${acc}/${segment}`, API_PREFIX);
    return axios.get(`${this.baseURL}${path}`);
  }

  // 使用对象解构和默认值
  async searchProducts({ query, category, minPrice, maxPrice, page = 1 }) {
    const basePath = `${API_PREFIX}/${RESOURCES.PRODUCTS}/search`;
    const params = new URLSearchParams({
      q: query,
      ...(category && { category }),
      ...(minPrice && { min_price: minPrice }),
      ...(maxPrice && { max_price: maxPrice }),
      page
    });
    return axios.get(`${this.baseURL}${basePath}?${params}`);
  }

  // 使用API版本切换
  async getProductV2(productId) {
    const path = `${API_V2_PREFIX}/${RESOURCES.PRODUCTS}/${productId}`;
    return axios.get(`${this.baseURL}${path}`);
  }

  // 使用正则表达式替换构建路径
  async getProductBySlug(slug) {
    const template = `${API_PREFIX}/${RESOURCES.PRODUCTS}/slug/:slug`;
    const path = template.replace(':slug', slug);
    return axios.get(`${this.baseURL}${path}`);
  }
}

module.exports = ComplexProductApi;
