const axios = require('axios');

/**
 * Authentication service
 */
class AuthService {
  constructor(baseURL) {
    this.baseURL = baseURL;
    this.token = null;
  }

  // POST /api/auth/login - User login
  async login(email, password) {
    const response = await axios.post(`${this.baseURL}/api/auth/login`, {
      email,
      password
    });
    this.token = response.data.token;
    return response.data;
  }

  // POST /api/auth/register - User registration
  async register(userData) {
    return axios.post(`${this.baseURL}/api/auth/register`, userData);
  }

  // POST /api/auth/logout - User logout
  async logout() {
    const response = await fetch(`${this.baseURL}/api/auth/logout`, {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${this.token}`
      }
    });
    this.token = null;
    return response.json();
  }

  // POST /api/auth/refresh - Refresh token
  async refreshToken() {
    return axios.post(`${this.baseURL}/api/auth/refresh`, {
      token: this.token
    });
  }

  // POST /api/auth/forgot-password - Request password reset
  async forgotPassword(email) {
    return fetch(`${this.baseURL}/api/auth/forgot-password`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ email })
    });
  }

  // POST /api/auth/reset-password/:token - Reset password
  async resetPassword(token, newPassword) {
    return axios.post(`${this.baseURL}/api/auth/reset-password/${token}`, {
      password: newPassword
    });
  }
}

module.exports = AuthService;
