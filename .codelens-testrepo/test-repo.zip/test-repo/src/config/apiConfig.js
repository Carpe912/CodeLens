/**
 * API Configuration
 * 定义API的基础路径和版本
 */

// API版本常量
const API_VERSION = 'v1';
const API_V2 = 'v2';

// 基础路径常量
const BASE_PATH = '/api';
const ADMIN_PATH = '/admin';

// 完整的API前缀
const API_PREFIX = `${BASE_PATH}/${API_VERSION}`;
const API_V2_PREFIX = `${BASE_PATH}/${API_V2}`;
const ADMIN_PREFIX = `${ADMIN_PATH}/${API_VERSION}`;

// 资源路径常量
const RESOURCES = {
  USERS: 'users',
  PRODUCTS: 'products',
  ORDERS: 'orders',
  CATEGORIES: 'categories',
  REVIEWS: 'reviews'
};

// 动态构建API路径的工具函数
function buildApiPath(resource, action = '') {
  const base = `${API_PREFIX}/${resource}`;
  return action ? `${base}/${action}` : base;
}

function buildAdminPath(resource, action = '') {
  const base = `${ADMIN_PREFIX}/${resource}`;
  return action ? `${base}/${action}` : base;
}

// 导出路径构建器
const ApiPaths = {
  // 用户相关
  users: {
    list: () => buildApiPath(RESOURCES.USERS),
    detail: (id) => `${buildApiPath(RESOURCES.USERS)}/${id}`,
    profile: (userId) => `${API_PREFIX}/${RESOURCES.USERS}/${userId}/profile`,
    avatar: (userId) => `${API_PREFIX}/${RESOURCES.USERS}/${userId}/avatar`,
    settings: (userId) => `${API_PREFIX}/${RESOURCES.USERS}/${userId}/settings`,
  },

  // 产品相关
  products: {
    list: () => buildApiPath(RESOURCES.PRODUCTS),
    detail: (id) => `${buildApiPath(RESOURCES.PRODUCTS)}/${id}`,
    byCategory: (categoryId) => `${API_PREFIX}/categories/${categoryId}/products`,
    search: (keyword) => `${buildApiPath(RESOURCES.PRODUCTS, 'search')}?q=${keyword}`,
  },

  // 订单相关
  orders: {
    list: () => buildApiPath(RESOURCES.ORDERS),
    detail: (orderId) => `${buildApiPath(RESOURCES.ORDERS)}/${orderId}`,
    items: (orderId) => `${API_PREFIX}/${RESOURCES.ORDERS}/${orderId}/items`,
    itemDetail: (orderId, itemId) => `${API_PREFIX}/${RESOURCES.ORDERS}/${orderId}/items/${itemId}`,
    tracking: (orderId) => `${API_PREFIX}/${RESOURCES.ORDERS}/${orderId}/tracking`,
  },

  // 管理员相关
  admin: {
    users: () => buildAdminPath(RESOURCES.USERS),
    userDetail: (id) => `${buildAdminPath(RESOURCES.USERS)}/${id}`,
    statistics: () => `${ADMIN_PREFIX}/statistics`,
  }
};

module.exports = {
  API_VERSION,
  API_V2,
  BASE_PATH,
  API_PREFIX,
  API_V2_PREFIX,
  ADMIN_PREFIX,
  RESOURCES,
  ApiPaths,
  buildApiPath,
  buildAdminPath
};
