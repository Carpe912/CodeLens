# Test Repository for CodeLens URL Indexing

这是一个专门设计用于测试 CodeLens URL 模式提取和索引功能的复杂测试仓库。

## 目的

本仓库包含各种复杂的 HTTP API 调用和路由定义场景，用于测试 CodeLens 的 URL 提取能力：

### 基础场景
- 简单 URL 模式: `/api/users`
- 路径参数: `/api/users/:id`
- 查询参数: `/api/products?category=electronics`
- 多层嵌套路径: `/api/orders/:orderId/items/:itemId`
- 不同 HTTP 方法: GET, POST, PUT, DELETE, PATCH
- 多种 HTTP 客户端: `fetch`, `axios`

### 复杂场景（重点测试）
- **常量定义的路径前缀**: 使用 `API_PREFIX`, `BASE_PATH` 等常量
- **动态路径构建**: 通过函数返回值生成路径
- **业务组件传参**: 组件方法接收参数后动态构建请求路径
- **路径工厂模式**: 使用工厂类生成标准化路径
- **条件路径**: 根据业务逻辑选择不同路径
- **模板字符串**: 使用 `:placeholder` 占位符和 `replace` 方法
- **循环生成路径**: 使用 `map`, `forEach` 批量生成请求
- **嵌套对象路径**: 使用对象方法链式调用构建路径
- **高阶函数**: 使用闭包和函数返回函数生成路径
- **Proxy 动态方法**: 使用 Proxy 动态拦截属性访问

## 文件结构

```
test-repo/
├── src/
│   ├── config/
│   │   └── apiConfig.js              # API配置：常量、路径构建器
│   ├── api/
│   │   ├── userApi.js                # 基础用户API
│   │   ├── advancedUserApi.js        # 高级用户API（使用配置常量）
│   │   ├── productApi.js             # 基础产品API
│   │   ├── complexProductApi.js      # 复杂产品API（多种路径构建方式）
│   │   ├── orderApi.js               # 基础订单API
│   │   └── dynamicOrderApi.js        # 动态订单API（业务参数传递）
│   ├── components/
│   │   └── UserDashboard.js          # 业务组件（模拟真实业务场景）
│   ├── utils/
│   │   └── apiFactory.js             # API工厂（工厂模式、Proxy）
│   ├── routes/
│   │   ├── userRoutes.js             # 用户路由定义
│   │   ├── productRoutes.js          # 产品路由定义
│   │   └── complexRoutes.js          # 复杂路由（循环、条件、工厂）
│   ├── services/
│   │   └── authService.js            # 认证服务
│   └── server.js                     # Express服务器
├── package.json
└── README.md
```

## 测试场景详解

### 1. 常量定义路径 (apiConfig.js)
```javascript
const API_PREFIX = '/api/v1';
const path = `${API_PREFIX}/users/${userId}`;
```

### 2. 函数返回路径 (advancedUserApi.js)
```javascript
const path = ApiPaths.users.detail(id);
return this.client.get(path);
```

### 3. 业务组件传参 (UserDashboard.js)
```javascript
async loadOrderDetails(orderId) {
  const order = await this.orderApi.getOrderDetail(orderId);
  const tracking = await this.orderApi.getOrderTracking(orderId);
}
```

### 4. 工厂模式 (apiFactory.js)
```javascript
const path = this.factory.resourceWithId('products', id);
const nestedPath = this.factory.nestedResource('users', userId, 'orders', orderId);
```

### 5. 条件路径 (complexProductApi.js)
```javascript
const path = includeOrders ? `${basePath}/orders` : basePath;
```

### 6. 循环生成 (dynamicOrderApi.js)
```javascript
const requests = orderIds.map(orderId => {
  const path = `${API_PREFIX}/orders/${orderId}`;
  return this.client.get(path);
});
```

### 7. 模板替换 (complexProductApi.js)
```javascript
const template = '/api/v1/products/slug/:slug';
const path = template.replace(':slug', slug);
```

### 8. 路由工厂 (complexRoutes.js)
```javascript
function createResourceRoutes(basePath, resourceName) {
  router.get(`${basePath}/${resourceName}`, handler);
  router.get(`${basePath}/${resourceName}/:id`, handler);
}
```

## 预期提取的 URL 模式

CodeLens 应该能够提取以下类型的 URL 模式：

### 基础模式
- `/api/v1/users`
- `/api/v1/users/:id`
- `/api/v1/products/:id`
- `/api/v1/orders/:orderId/items/:itemId`

### 通过常量构建的模式
- `/api/v1/users/:userId/profile`
- `/api/v1/users/:userId/settings`
- `/api/v1/users/:userId/orders`

### 嵌套资源模式
- `/api/v1/categories/:categoryId/products`
- `/api/v1/orders/:orderId/items`
- `/api/v1/users/:userId/orders/:orderId/items/:itemId`

### 特殊模式
- `/api/v1/products/search`
- `/api/v1/products/slug/:slug`
- `/api/v1/users/:userId/notifications`
- `/api/v2/products/:id` (多版本API)

## 测试步骤

1. 在 CodeLens 中添加此仓库
2. 等待索引完成
3. 检查日志中是否有 "Invalid line number" 错误
4. 验证 `url_patterns` 表中的数据：
   - 检查是否正确提取了常量定义的路径
   - 检查是否正确提取了函数返回的路径
   - 检查是否正确提取了业务组件中的路径
5. 测试 URL 搜索功能
6. 验证新的 `|||` 分隔符是否正常工作

## 关键测试点

- ✅ 常量拼接的路径能否正确提取
- ✅ 函数返回的路径能否正确提取
- ✅ 模板字符串路径能否正确提取
- ✅ 条件分支中的路径能否都被提取
- ✅ 循环生成的路径能否正确提取
- ✅ 嵌套对象方法返回的路径能否提取
- ✅ 工厂模式生成的路径能否提取
- ✅ 路径中包含特殊字符（如冒号）时是否会出错
